import 'package:flutter/material.dart';
import 'lesson_screen.dart';
import 'quiz_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('GCE MASTER'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Study. Test. Master.',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('Learn lessons, take quizzes, track mastery and identify weak topics.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Mathematics',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ListTile(
            leading: const Icon(Icons.menu_book),
            title: const Text('Indices'),
            subtitle: const Text('Lesson and examples'),
            trailing: const Icon(Icons.chevron_right),
            onTap: null,
          ),
          ListTile(
            leading: const Icon(Icons.quiz),
            title: const Text('Indices Quiz'),
            subtitle: const Text('Test your understanding'),
            trailing: const Icon(Icons.chevron_right),
            onTap: null,
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            icon: const Icon(Icons.menu_book),
            label: const Text('Open sample lesson'),
            onPressed: () {
              Navigator.push(context,
                MaterialPageRoute(builder: (_) => const LessonScreen()));
            },
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            icon: const Icon(Icons.quiz),
            label: const Text('Take sample quiz'),
            onPressed: () {
              Navigator.push(context,
                MaterialPageRoute(builder: (_) => const QuizScreen()));
            },
          ),
        ],
      ),
    );
  }
}
