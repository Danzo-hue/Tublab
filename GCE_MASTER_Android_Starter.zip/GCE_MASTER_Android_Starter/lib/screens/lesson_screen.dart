import 'package:flutter/material.dart';

class LessonScreen extends StatelessWidget {
  const LessonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Indices')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('Law of indices',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          SizedBox(height: 12),
          Text('For a non-zero number a, a^m × a^n = a^(m+n).'),
          SizedBox(height: 12),
          Text('Example'),
          SizedBox(height: 4),
          Text('2³ × 2² = 2⁵ = 32'),
          SizedBox(height: 20),
          Text('Note: This is starter content. Official Cameroon GCE syllabus content should be added and verified before publication.'),
        ],
      ),
    );
  }
}
