import 'package:flutter/material.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int score = 0;
  final questions = const [
    ('2³ × 2² = ?', ['2⁵', '2⁶', '2⁸', '4⁵'], 0),
    ('5⁴ ÷ 5² = ?', ['5²', '5⁶', '5⁸', '25⁴'], 0),
    ('(3²)³ = ?', ['3⁵', '3⁶', '3⁸', '6³'], 1),
    ('10⁰ = ?', ['0', '1', '10', '100'], 1),
    ('aᵐ × aⁿ = ?', ['aᵐ⁻ⁿ', 'aᵐⁿ', 'aᵐ⁺ⁿ', 'aᵐ/ⁿ'], 2),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Indices Quiz')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: questions.length + 1,
        itemBuilder: (context, index) {
          if (index == questions.length) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Text('Score: $score / ${questions.length}',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            );
          }
          final q = questions[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${index + 1}. ${q.$1}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                  ...List.generate(q.$2.length, (i) => RadioListTile<int>(
                    value: i,
                    groupValue: null,
                    title: Text(q.$2[i]),
                    onChanged: (value) {
                      if (value == q.$3) {
                        setState(() => score++);
                      }
                    },
                  )),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
