# GCE MASTER — Android starter

Study. Test. Master.

This is a starter Flutter project for the GCE MASTER Android application.

Planned features:
- Cameroon GCE O/L and A/L subjects and syllabus topics
- Lesson notes
- Offline lessons and quizzes
- Quiz scoring and mastery estimates
- Weak-topic detection
- Teacher-managed content with authorised accounts
- Synchronisation when internet becomes available

Important: the sample Mathematics/Indices material is demonstration content only. Official syllabus and examination content must be verified before publication.
